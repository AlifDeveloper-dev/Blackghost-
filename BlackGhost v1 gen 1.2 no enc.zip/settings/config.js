const fs = require('fs')
//~~~~~~~~~SETTING BOT~~~~~~~~~~//
global.owner = "6281361984560"
global.nama = "𝐈𝐗𝐈𝐙𝐃𝐄𝐕"
global.ch = 'https://whatsapp.com/channel/0029Vb3LHTM1iUxRbioa1Z3K'
global.status = true
global.author = "Blackghost"
global.packname = 'ixizdev'
//====== [ THEME URL & URL ] ========//
global.thumb = fs.readFileSync('./ixizkiller.jpg'); // Buffer Image
global.thumbnail = 'https://files.catbox.moe/r8tn10.jpg'
global.Url = '-'
global.mess = {
    owner: "no, this is for owners only",
    group: "this is for groups only",
    private: "this is specifically for private chat"
}

global.packname = '𝙄𝙭𝙞𝙯𝘿𝙚𝙫'
global.author = '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n'

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
